import {combineReducers} from 'redux';

//eslint-disable-next-line
import common from './reducers/common.reducer';

export default combineReducers({
    common
})